﻿using System;

namespace Saitynas1Lab.Data.Entities
{
    public class Post
    {
        public int Id { get; set; }
        public string GameName { get; set; }
        public int Price { get; set; }
        public string Body { get; set; }
        public DateTime CreationDateUtc { get; set; }
      



    }
}
